package websocket

import (
	"beanpon_messenger/config"
	"beanpon_messenger/models"
	"beanpon_messenger/utils"
	"beanpon_messenger/xmpp"
	"bytes"
	"encoding/json"
	"github.com/google/uuid"
	"log"
	"net/http"
	"sync"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/gorilla/websocket"
	"gorm.io/gorm"
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		return true
	},
}

// Client WebSocket bağlantısını temsil eder
type Client struct {
	UserID         uint
	Conn           *websocket.Conn
	Send           chan []byte
	Hub            *Hub
	ActiveChatWith *uint
	// Hazırda AÇIQ olan qrup çatı (conversation_id). DM ActiveChatWith-in
	// qrup ekvivalenti — istifadəçi qrup səhifəsindədirsə həmin qrupun
	// mesajları üçün FCM push GÖNDƏRİLMİR (onsuz da görür).
	ActiveGroupChat *uint

	// closeOnce — `Send` kanalının YALNIZ bir dəfə bağlanmasını təmin edir.
	// Əvvəllər həm registerClient (köhnə bağlantı atılarkən), həm də
	// unregisterClient eyni kanalı bağlaya bilirdi → ikiqat close panic →
	// goroutine ölür → həmin user-in soketi səssizcə qopurdu. İndi bütün
	// close-lar bu Once üzərindən keçir (idempotent).
	closeOnce sync.Once
}

// closeSend `Send` kanalını təhlükəsiz (idempotent) bağlayır. İstənilən
// qədər çağırıla bilər, yalnız ilki effekt edir — beləliklə ikiqat close
// panic-i mümkün deyil.
func (c *Client) closeSend() {
	c.closeOnce.Do(func() {
		close(c.Send)
	})
}

// Hub tüm client'ları yönetir
type Hub struct {
	clients           map[uint]*Client
	register          chan *Client
	unregister        chan *Client
	broadcast         chan *Message
	mutex             sync.RWMutex
	db                *gorm.DB
	encryptionService interface {
		EncryptMessage(plainText string) (string, error)
		DecryptMessage(encryptedText string) (string, error)
	}
	httpClient *http.Client   // ← YENI
	config     *config.Config // ← YENI

	// moderationEnqueue — WS ilə göndərilən mesajları arxa-plan moderasiya
	// analizinə qoyur. Qeyri-bloklayıcıdır. nil olduqda atlanır.
	// Lokal funksiya tipi kimi saxlanır ki, services paketinə birbaşa
	// asılılıq (və potensial import cycle) olmasın.
	moderationEnqueue func(messageID string, senderID, receiverID uint, plainText string, createdAt time.Time)

	// xmpp — XMPP bridge (counterpart: none; server-only transport migration).
	// nil when the XMPP subsystem is disabled (XMPP_ENABLED=false). When set,
	// the Hub consults it on the egress path to route 1:1 / group messages to
	// NEW (XMPP) recipients while OLD recipients keep the legacy WS path. See
	// xmpp/WIRING.md.
	xmpp *xmpp.Bridge
}

// SetModerationEnqueue — WS axını üçün moderasiya enqueue callback-ini bağlayır.
// main.go-da queue qurulduqdan sonra çağırılır.
func (h *Hub) SetModerationEnqueue(fn func(messageID string, senderID, receiverID uint, plainText string, createdAt time.Time)) {
	h.moderationEnqueue = fn
}

// IncomingMessage client'tan gelen mesaj yapısı
type IncomingMessage struct {
	Type       string      `json:"type"`
	ReceiverID uint        `json:"receiver_id,omitempty"`
	Content    string      `json:"content,omitempty"`
	Data       interface{} `json:"data,omitempty"`
}

// OutgoingMessage client'a gönderilen mesaj yapısı
type OutgoingMessage struct {
	Type string      `json:"type"`
	Data interface{} `json:"data"`
}

// Message WebSocket mesaj yapısı (broadcast için)
type Message struct {
	Type       string      `json:"type"`
	ReceiverID uint        `json:"receiver_id"`
	Data       interface{} `json:"data"`
}

// MessageData veritabanı mesaj yapısı
type MessageData struct {
	ID         string    `json:"id"`
	SenderID   uint      `json:"sender_id"`
	ReceiverID uint      `json:"receiver_id"`
	Text       string    `json:"text"`
	Read       bool      `json:"read"`
	CreatedAt  time.Time `json:"created_at"`
	UpdatedAt  time.Time `json:"updated_at"`
}

// NewHub yeni hub oluştur
func NewHub(db *gorm.DB, encryptionService interface {
	EncryptMessage(plainText string) (string, error)
	DecryptMessage(encryptedText string) (string, error)
}, config *config.Config) *Hub { // ← config parametri əlavə
	return &Hub{
		clients:           make(map[uint]*Client),
		register:          make(chan *Client),
		unregister:        make(chan *Client),
		broadcast:         make(chan *Message),
		db:                db,
		encryptionService: encryptionService,
		httpClient:        &http.Client{Timeout: 10 * time.Second}, // ← YENI
		config:            config,                                  // ← YENI
	}
}

// Run hub'ı çalıştır
func (h *Hub) Run() {
	for {
		select {
		case client := <-h.register:
			h.registerClient(client)

		case client := <-h.unregister:
			h.unregisterClient(client)

		case message := <-h.broadcast:
			h.broadcastMessage(message)
		}
	}
}

// registerClient client'ı kaydet
func (h *Hub) registerClient(client *Client) {
	h.mutex.Lock()
	defer h.mutex.Unlock()

	if existingClient, exists := h.clients[client.UserID]; exists {
		delete(h.clients, existingClient.UserID)
		// DİQQƏT: Köhnə client-in `Send` kanalını BURADA bağlamırıq.
		// Yalnız soketi bağlayırıq — bu, köhnə client-in readPump-ını qıracaq,
		// o da defer-də `unregister`-ə gedəcək və `Send` orada (closeSend ilə)
		// təhlükəsiz bağlanacaq. Beləliklə kanal yalnız BİR yerdən bağlanır.
		existingClient.Conn.Close()
		//log.Printf("Kullanıcı %d eski bağlantısı temizlendi", client.UserID)
	}

	h.clients[client.UserID] = client
	//log.Printf("Kullanıcı %d WebSocket'e bağlandı", client.UserID)

	//online oldugunu yazir
	h.setUserOnline(client.UserID)

	// XMPP: this user is on a legacy WS client → mark them OLD in the registry
	// so the egress seam routes their incoming messages over legacy WS. No-op
	// when XMPP is disabled.
	h.markLegacyPresence(client.UserID)

	// Kullanıcı online durumunu diğer kullanıcılara bildir
	h.broadcastUserStatus(client.UserID, "online")

	//İlk bağlantıda okunmamış mesaj sayısını gönder
	go h.SendUnreadCountUpdate(client.UserID)

	// Bağlandıktan sonra son 30 mesajı gönder
	go h.sendRecentMessages(client)
}

// unregisterClient client'ı çıkar
func (h *Hub) unregisterClient(client *Client) {
	h.mutex.Lock()
	defer h.mutex.Unlock()

	// Identity yoxlaması: map-dəki client məhz BU client-dirmi?
	// Reconnect zamanı köhnə client soketi bağlanıb gec `unregister`-ə gələ
	// bilər, amma `clients[UserID]` artıq YENİ client-ə işarə edir. Köhnə
	// client yeni client-i map-dən silməməli və yeni user-i offline
	// göstərməməlidir. Yalnız öz `Send` kanalını bağlamalıdır.
	current, exists := h.clients[client.UserID]

	if exists && current == client {
		// Bu, hazırkı aktiv client-dir — tam təmizlik.
		delete(h.clients, client.UserID)

		h.setUserOffline(client.UserID)

		client.closeSend()

		_ = client.Conn.Close()
		//log.Printf("Kullanıcı %d WebSocket'ten ayrıldı", client.UserID)

		// Kullanıcı offline durumunu diğer kullanıcılara bildir
		h.broadcastUserStatus(client.UserID, "offline")
	} else {
		// Köhnə/əvəz olunmuş client — yeni bağlantıya toxunma, yalnız
		// öz kanalını və soketini təmizlə.
		client.closeSend()
		_ = client.Conn.Close()
	}
}

// broadcastUserStatus kullanıcı durumunu yayınla
func (h *Hub) broadcastUserStatus(userID uint, status string) {
	statusMessage := &Message{
		Type: "user_status",
		Data: map[string]interface{}{
			"user_id": userID,
			"status":  status,
		},
	}

	// Tüm bağlı kullanıcılara gönder
	for _, client := range h.clients {
		if client.UserID != userID { // Kendisi hariç
			select {
			case client.Send <- h.messageToBytes(statusMessage):
			default:
				go func(c *Client) {
					h.unregister <- c
				}(client)
			}
		}
	}
}

// broadcastMessage mesajı yayınla
func (h *Hub) broadcastMessage(message *Message) {
	h.mutex.RLock()
	defer h.mutex.RUnlock()

	if client, exists := h.clients[message.ReceiverID]; exists {
		select {
		case client.Send <- h.messageToBytes(message):
			// Canlı new_message push-u BAĞLI alıcıya çatdısa (kanala yazıla
			// bildi) → server tərəfdə dərhal delivered=true (WhatsApp davranışı,
			// ani iki tick). Uğursuz göndərmə (default branch) bura düşmür.
			h.maybeMarkLivePushDelivered(message)
		default:
			go func() {
				h.unregister <- client
			}()
		}
	}
}

// maybeMarkLivePushDelivered — canlı `new_message` push-u bağlı alıcının Send
// kanalına uğurla yazıldıqda mesajı delivered=true işarələyir və göndərənə
// `message_delivered` event-i göndərir. Client ack-i (`mark_delivered` frame-i,
// bax handleMarkDelivered) push/offline gəlişlərini örtür; bu yol yalnız ani
// iki tick üçündür. delivered=false şərti ikiqat emit-in qarşısını alır.
func (h *Hub) maybeMarkLivePushDelivered(message *Message) {
	if message.Type != "new_message" {
		return
	}

	dataMap, ok := message.Data.(map[string]interface{})
	if !ok {
		return
	}

	// Tarixi mesajlar ayrı tiplə (history_message) gedir — yenə də qoruyucu.
	if isHistory, _ := dataMap["is_history"].(bool); isHistory {
		return
	}

	msgID, ok := dataMap["id"].(string)
	if !ok || msgID == "" {
		return
	}
	senderID, ok := dataMap["sender_id"].(uint)
	if !ok {
		return
	}
	receiverID, ok := dataMap["receiver_id"].(uint)
	if !ok {
		return
	}

	// new_message həm göndərənin echo-suna, həm alıcıya gedir — yalnız
	// ALICININ nüsxəsində işarələ (göndərən echo-su delivered demək deyil).
	if message.ReceiverID != receiverID {
		return
	}

	// DB işi hub Run döngüsünü bloklamasın deyə goroutine-də. h app-ömürlü
	// singleton-dur — retain/leak problemi yoxdur.
	go func() {
		res := h.db.Model(&models.Message{}).
			Where("id = ? AND delivered = false", msgID).
			Update("delivered", true)
		if res.Error != nil {
			log.Printf("live-push delivered işarələmə xətası: %v", res.Error)
			return
		}
		if res.RowsAffected == 0 {
			// WS göndərmə yolu mesajı DB-yə ASYNC yazır (readPump-dakı
			// goroutine) — sətir hələ mövcud olmaya bilər. Bir dəfə qısa
			// gözləyib təkrar yoxla; yenə 0 olsa (artıq delivered/read və ya
			// sətir yoxdur) event getmir — client ack-i onsuz da örtəcək.
			time.Sleep(1 * time.Second)
			res = h.db.Model(&models.Message{}).
				Where("id = ? AND delivered = false", msgID).
				Update("delivered", true)
			if res.Error != nil || res.RowsAffected == 0 {
				return
			}
		}

		h.SendToUser(senderID, "message_delivered", map[string]interface{}{
			"other_user_id": receiverID,
			"message_ids":   []string{msgID},
		})
	}()
}

// SendToUser belirli kullanıcıya mesaj gönder
func (h *Hub) SendToUser(userID uint, messageType string, data interface{}) {
	message := &Message{
		Type:       messageType,
		ReceiverID: userID,
		Data:       data,
	}
	h.broadcast <- message
}

// SendToMultipleUsers birden fazla kullanıcıya mesaj gönder
func (h *Hub) SendToMultipleUsers(userIDs []uint, messageType string, data interface{}) {
	for _, userID := range userIDs {
		h.SendToUser(userID, messageType, data)
	}
}

// HandleNewMessage yeni mesajı handle et ve WebSocket üzerinden yayınla
func (h *Hub) HandleNewMessage(senderID, receiverID uint, messageID, content, msgType string, createdAt time.Time, replyToMessageID *string, storyID *uint, conversationStatus string, silent bool) {
	messageData := map[string]interface{}{
		"id":                  messageID,
		"sender_id":           senderID,
		"receiver_id":         receiverID,
		"story_id":            storyID,
		"reply_to_message_id": replyToMessageID,
		"text":                content,
		"type":                msgType,
		"read":                false,
		"created_at":          createdAt.UTC().Format(time.RFC3339),
		"is_history":          false,
	}

	// Reply mesajı kontrolü
	if replyToMessageID != nil {
		var replyMessage models.Message
		if err := h.db.Where("id = ?", *replyToMessageID).First(&replyMessage).Error; err == nil {
			replyDecryptedText, err := h.encryptionService.DecryptMessage(replyMessage.EncryptedText)
			if err != nil {
				replyDecryptedText = "Mesaj çözülemedi"
			}

			messageData["reply_to_message"] = map[string]interface{}{
				"id":         replyMessage.ID,
				"sender_id":  replyMessage.SenderID,
				"text":       replyDecryptedText,
				"created_at": replyMessage.CreatedAt,
			}
		}
	}

	// Story bilgisi kontrolü
	if storyID != nil {
		var story models.Story
		if err := h.db.Where("id = ?", *storyID).First(&story).Error; err == nil {
			storyResponse := map[string]interface{}{
				"id":         story.ID,
				"type":       story.Type,
				"media_url":  utils.PrependS3URL(&story.MediaURL),
				"content":    story.Content,
				"user_id":    story.UserID,
				"created_at": story.CreatedAt,
				"available":  true,
			}

			if story.Type == "video" && story.MediaMetadata != nil {
				var metadata map[string]interface{}
				if err := json.Unmarshal([]byte(*story.MediaMetadata), &metadata); err == nil {
					if thumbnailURL, exists := metadata["thumbnail_url"].(string); exists && thumbnailURL != "" {
						storyResponse["thumbnail_url"] = utils.PrependS3URL(&thumbnailURL)
					}
				}
			}

			messageData["story"] = storyResponse
		} else {
			messageData["story"] = map[string]interface{}{
				"id":        *storyID,
				"available": false,
				"message":   "Bu story artık mevcut değil",
			}
		}
	}

	// Hem gönderen hem de alıcıya gönder.
	//
	// EGRESS SEAM (XMPP) — DUAL DELIVERY for zero message loss.
	//
	// The message is ALWAYS delivered over the legacy WS channel (to both the
	// sender's echo and the receiver). ADDITIONALLY, if the receiver is on a
	// NEW (XMPP) client, the same message is published as an XMPP stanza.
	//
	// Why dual-deliver instead of "XMPP OR WS"? A NEW client connects to BOTH
	// transports (the iOS facade keeps the legacy WS open while adding XMPP),
	// and it DEDUPLICATES inbound messages by id. So:
	//   - receiver on legacy WS only  → gets it via WS.
	//   - receiver on XMPP + WS        → gets both, dedup shows one.
	//   - receiver transiently offline on XMPP (presence TTL) → still gets it
	//     via WS; nothing is lost. (With auth_method: jwt, ejabberd has no
	//     mod_offline, so an XMPP-only delivery to an offline JID would be
	//     dropped — dual delivery removes that risk.)
	// The message is persisted in the DB regardless, so history/push cover the
	// fully-offline case exactly as today.
	//
	// When the XMPP subsystem is disabled this is byte-for-byte the old
	// behaviour (the XMPP block is skipped). See xmpp/WIRING.md.
	userIDs := []uint{senderID, receiverID}
	h.SendToMultipleUsers(userIDs, "new_message", messageData) // legacy WS (always)

	if h.xmpp != nil && h.xmpp.Enabled() && h.xmpp.Registry().IsXMPP(receiverID) {
		// Best-effort XMPP copy for the NEW client. iOS dedups by id, so this
		// never double-shows alongside the WS copy.
		h.xmpp.RouteDM(xmpp.DM1to1{
			MessageID:        messageID,
			SenderID:         senderID,
			ReceiverID:       receiverID,
			Text:             content,
			Kind:             msgType,
			ReplyToMessageID: derefStr(replyToMessageID),
		})
	}

	h.sendConversationUpdate(senderID, receiverID, messageData)

	go h.SendUnreadCountUpdate(receiverID)

	// 🔕 SƏSSİZ GÖNDƏRMƏ: göndərən "səssiz göndər" seçibsə, mesaj normal çatır
	// (DB + WS + unread), AMMA qarşı tərəfə push notification GETMİR.
	if silent {
		log.Printf("🔕 Səssiz mesaj: sender=%d → receiver=%d, push göndərilmir",
			senderID, receiverID)
		return
	}

	// 🎯 Sadece active conversation'larda notification gönder
	if conversationStatus == "active" {
		if !h.IsUserOnline(receiverID) {
			go h.sendPushNotification(senderID, receiverID, content, msgType)
		} else if !h.IsUserInChatWith(receiverID, senderID) {
			go h.sendPushNotification(senderID, receiverID, content, msgType)
		}
	}
}

// Bu yeni fonksiyonu ekle
func (h *Hub) sendConversationUpdate(senderID, receiverID uint, messageData map[string]interface{}) {
	// Gönderen ve alıcının conversation listelerini güncelle
	conversationData := map[string]interface{}{
		"type":              "conversation_update",
		"message_data":      messageData,
		"other_user_id":     receiverID, // Gönderende receiver görünür
		"last_message":      messageData["text"],
		"last_message_time": messageData["created_at"],
		"is_from_me":        true,
	}

	// Gönderene
	h.SendToUser(senderID, "conversation_update", conversationData)

	// Alıcıya (onun için other_user_id sender olacak)
	conversationDataForReceiver := map[string]interface{}{
		"type":              "conversation_update",
		"message_data":      messageData,
		"other_user_id":     senderID, // Alıcıda sender görünür
		"last_message":      messageData["text"],
		"last_message_time": messageData["created_at"],
		"is_from_me":        false,
	}

	h.SendToUser(receiverID, "conversation_update", conversationDataForReceiver)
}

// HandleMessageRead mesaj okundu durumunu handle et
func (h *Hub) HandleMessageRead(messageID string, senderID, readerID uint) {
	readData := map[string]interface{}{
		"message_id": messageID,
		"reader_id":  readerID,
		"read_at":    time.Now().UTC(),
	}

	// Sadece gönderene bildir (alıcı zaten okudu)
	h.SendToUser(senderID, "message_read", readData)

	go h.SendUnreadCountUpdate(readerID)

	log.Printf("Mesaj okundu WebSocket üzerinden yayınlandı: %s", messageID)
}

// IsUserOnline kullanıcının online olup olmadığını kontrol et
func (h *Hub) IsUserOnline(userID uint) bool {
	h.mutex.RLock()
	defer h.mutex.RUnlock()
	_, exists := h.clients[userID]
	return exists
}

// GetConnectedUsersCount bağlı kullanıcı sayısı
func (h *Hub) GetConnectedUsersCount() int {
	h.mutex.RLock()
	defer h.mutex.RUnlock()
	return len(h.clients)
}

// GetConnectedUsers bağlı kullanıcı listesi
func (h *Hub) GetConnectedUsers() []uint {
	h.mutex.RLock()
	defer h.mutex.RUnlock()

	users := make([]uint, 0, len(h.clients))
	for userID := range h.clients {
		users = append(users, userID)
	}
	return users
}

func (h *Hub) messageToBytes(message *Message) []byte {
	outgoing := &OutgoingMessage{
		Type: message.Type,
		Data: message.Data,
	}

	data, err := json.Marshal(outgoing)
	if err != nil {
		log.Printf("JSON marshal hatası: %v", err)
		return []byte(`{"type":"error","data":"Message format error"}`)
	}
	return data
}

// sendRecentMessages kullanıcıya son 30 mesajı gönder
// sendRecentMessages kullanıcıya son 30 mesajı gönder
func (h *Hub) sendRecentMessages(client *Client) {
	var messages []struct {
		ID               string  `json:"id"`
		SenderID         uint    `json:"sender_id"`
		ReceiverID       uint    `json:"receiver_id"`
		StoryID          *uint   `json:"story_id"` // YENİ ALAN
		ReplyToMessageID *string `json:"reply_to_message_id"`
		Text             string  `json:"text"`
		Read             bool    `json:"read"`
		SenderReaction   *string `json:"sender_reaction"`
		ReceiverReaction *string `json:"receiver_reaction"`
		CreatedAt        string  `json:"created_at"`
		// Reply mesajı bilgileri
		ReplyToMessageText   *string `json:"reply_to_message_text"`
		ReplyToMessageSender *uint   `json:"reply_to_message_sender"`
		ReplyToMessageType   *string `json:"reply_to_message_type"`
		ReplyToCreatedAt     *string `json:"reply_to_created_at"`
		// Story bilgileri
		StoryType      *string `json:"story_type"`
		StoryMediaURL  *string `json:"story_media_url"`
		StoryContent   *string `json:"story_content"`
		StoryUserID    *uint   `json:"story_user_id"`
		StoryCreatedAt *string `json:"story_created_at"`
	}

	query := `
    SELECT 
        m.id, 
        m.sender_id, 
        m.receiver_id,
        m.story_id,
        m.reply_to_message_id,
        m.encrypted_text as text,
        m.read,
        m.sender_reaction,
        m.receiver_reaction,
        m.created_at,
        reply.encrypted_text as reply_to_message_text,
        reply.sender_id as reply_to_message_sender,
        reply.created_at as reply_to_created_at,
        s."type" as story_type,
        s.media_url as story_media_url,
        s.content as story_content,
        s.user_id as story_user_id,
        s.created_at as story_created_at
    FROM messages m
    LEFT JOIN messages reply ON m.reply_to_message_id = reply.id
    LEFT JOIN stories s ON m.story_id = s.id
    WHERE (m.sender_id = ? OR m.receiver_id = ?)
    AND (
        CASE 
            WHEN m.sender_id = ? THEN m.is_deleted_by_sender = false
            ELSE m.is_deleted_by_receiver = false
        END
    )
    ORDER BY m.created_at ASC 
    LIMIT 30
`

	if err := h.db.Raw(query, client.UserID, client.UserID, client.UserID).Scan(&messages).Error; err != nil {
		log.Printf("Son mesajlar alınamadı: %v", err)
		return
	}

	for i := 0; i < len(messages); i++ {
		msg := messages[i]

		decryptedText, err := h.encryptionService.DecryptMessage(msg.Text)
		if err != nil {
			decryptedText = "Mesaj çözülemedi"
		}

		messageData := map[string]interface{}{
			"id":                  msg.ID,
			"sender_id":           msg.SenderID,
			"receiver_id":         msg.ReceiverID,
			"story_id":            msg.StoryID, // YENİ ALAN
			"reply_to_message_id": msg.ReplyToMessageID,
			"text":                decryptedText,
			"read":                msg.Read,
			"sender_reaction":     msg.SenderReaction,
			"receiver_reaction":   msg.ReceiverReaction,
			"created_at":          msg.CreatedAt,
			"is_history":          true,
		}

		// Story bilgisi varsa ekle
		if msg.StoryID != nil {
			if msg.StoryType != nil {
				// Story hala mevcut
				messageData["story"] = map[string]interface{}{
					"id":         *msg.StoryID,
					"type":       *msg.StoryType,
					"media_url":  msg.StoryMediaURL,
					"content":    msg.StoryContent,
					"user_id":    *msg.StoryUserID,
					"created_at": msg.StoryCreatedAt,
					"available":  true,
				}
			} else {
				// Story silinmiş veya erişilemiyor
				messageData["story"] = map[string]interface{}{
					"id":        *msg.StoryID,
					"available": false,
					"message":   "Bu story artık mevcut değil",
				}
			}
		}

		// Reply mesajı varsa ekle (mevcut kod aynı...)
		if msg.ReplyToMessageID != nil && msg.ReplyToMessageText != nil {
			replyDecryptedText, err := h.encryptionService.DecryptMessage(*msg.ReplyToMessageText)
			if err != nil {
				replyDecryptedText = "Mesaj çözülemedi"
			}

			messageData["reply_to_message"] = map[string]interface{}{
				"id":         *msg.ReplyToMessageID,
				"sender_id":  msg.ReplyToMessageSender,
				"text":       replyDecryptedText,
				"type":       msg.ReplyToMessageType,
				"created_at": msg.ReplyToCreatedAt,
			}
		}

		outgoingMessage := &OutgoingMessage{
			Type: "history_message",
			Data: messageData,
		}

		select {
		case client.Send <- h.messageToBytes(&Message{Type: outgoingMessage.Type, Data: outgoingMessage.Data}):
		default:
			log.Printf("Kullanıcı %d için mesaj geçmişi gönderilemedi", client.UserID)
			return
		}
	}

	completedMessage := &OutgoingMessage{
		Type: "history_loaded",
		Data: map[string]interface{}{
			"message": "Son 30 mesaj yüklendi",
			"count":   len(messages),
		},
	}

	select {
	case client.Send <- h.messageToBytes(&Message{Type: completedMessage.Type, Data: completedMessage.Data}):
	default:
		log.Printf("Kullanıcı %d için tamamlanma bildirimi gönderilemedi", client.UserID)
	}
}

// HandleWebSocket WebSocket bağlantısını handle et
func (h *Hub) HandleWebSocket(c *gin.Context) {
	userID, exists := c.Get("user_id")
	if !exists {
		log.Printf("WebSocket: user_id context'te bulunamadı")
		c.JSON(http.StatusUnauthorized, gin.H{"error": "Unauthorized"})
		return
	}

	log.Printf("WebSocket: Context'ten alınan userID: %v (tip: %T)", userID, userID)

	conn, err := upgrader.Upgrade(c.Writer, c.Request, nil)
	if err != nil {
		log.Printf("WebSocket upgrade hatası: %v", err)
		return
	}

	client := &Client{
		UserID: userID.(uint),
		Conn:   conn,
		Send:   make(chan []byte, 256),
		Hub:    h,
	}

	h.register <- client

	go client.writePump()
	go client.readPump()
}

// readPump client'tan mesaj oku ve işle
func (c *Client) readPump() {
	defer func() {
		c.Hub.unregister <- c
	}()

	// Ping/Pong setup
	err := c.Conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	if err != nil {
		return
	}
	c.Conn.SetPongHandler(func(string) error {
		err := c.Conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		if err != nil {
			return err
		}
		return nil
	})

	for {
		_, messageBytes, err := c.Conn.ReadMessage()
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				log.Printf("WebSocket hatası: %v", err)
			}
			break
		}

		var incomingMsg IncomingMessage
		if err := json.Unmarshal(messageBytes, &incomingMsg); err != nil {
			log.Printf("Mesaj parse hatası: %v", err)
			continue
		}

		// Gelen mesajları işle
		c.handleIncomingMessage(&incomingMsg)
	}
}

// handleIncomingMessage gelen mesajları işle
func (c *Client) handleIncomingMessage(msg *IncomingMessage) {
	switch msg.Type {
	case "ping":
		// Ping mesajına pong ile cevap ver
		response := &OutgoingMessage{
			Type: "pong",
			Data: map[string]interface{}{
				"timestamp": time.Now().Unix(),
			},
		}
		c.sendMessage(response)

	case "typing":
		// Yazıyor durumunu karşı tarafa bildir (action: text yazma)
		if msg.ReceiverID > 0 {
			c.Hub.SendToUser(msg.ReceiverID, "user_typing", map[string]interface{}{
				"user_id": c.UserID,
				"typing":  true,
				"action":  "typing",
			})
		}

	case "typing_stop":
		// Yazmayı bıraktı durumunu karşı tarafa bildir
		if msg.ReceiverID > 0 {
			c.Hub.SendToUser(msg.ReceiverID, "user_typing", map[string]interface{}{
				"user_id": c.UserID,
				"typing":  false,
				"action":  "typing",
			})
		}

	case "recording":
		// Səs mesajı yazır (mic basılı tutub) — qarşı tərəfə bildir.
		// Eyni user_typing event-i, amma action: recording.
		if msg.ReceiverID > 0 {
			c.Hub.SendToUser(msg.ReceiverID, "user_typing", map[string]interface{}{
				"user_id": c.UserID,
				"typing":  true,
				"action":  "recording",
			})
		}

	case "recording_stop":
		// Səs yazmağı dayandırdı (buraxdı/ləğv etdi).
		if msg.ReceiverID > 0 {
			c.Hub.SendToUser(msg.ReceiverID, "user_typing", map[string]interface{}{
				"user_id": c.UserID,
				"typing":  false,
				"action":  "recording",
			})
		}

	case "group_typing":
		// Qrupda yazma — həmin qrupun digər üzvlərinə bildir.
		c.Hub.handleGroupTyping(c.UserID, msg.Data, true)

	case "group_typing_stop":
		// Qrupda yazmağı dayandırdı.
		c.Hub.handleGroupTyping(c.UserID, msg.Data, false)

	case "get_online_users":
		// Online kullanıcı listesini gönder
		onlineUsers := c.Hub.GetConnectedUsers()
		response := &OutgoingMessage{
			Type: "online_users",
			Data: map[string]interface{}{
				"users": onlineUsers,
				"count": len(onlineUsers),
			},
		}
		c.sendMessage(response)
	case "add_reaction":
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			log.Printf("Reaction data parse edilemedi")
			return
		}

		messageID, ok1 := dataMap["message_id"].(string)
		emoji, ok2 := dataMap["emoji"].(string)
		if !ok1 || !ok2 {
			log.Printf("MessageID veya emoji eksik")
			return
		}

		c.Hub.handleAddReaction(c.UserID, messageID, emoji)

	case "remove_reaction":
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			return
		}

		messageID, ok1 := dataMap["message_id"].(string)
		if !ok1 {
			return
		}

		c.Hub.handleRemoveReaction(c.UserID, messageID)
	case "send_message":
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			log.Printf("Mesaj data parse edilemedi")
			return
		}
		receiverIDFloat, ok1 := dataMap["receiver_id"].(float64)
		content, ok2 := dataMap["text"].(string)
		if !ok1 || !ok2 {
			log.Printf("Geçersiz mesaj verisi")
			return
		}
		receiverID := uint(receiverIDFloat)
		var replyToMessageID *string
		var storyID *uint
		var msgType string

		if replyID, exists := dataMap["reply_to_message_id"].(string); exists && replyID != "" {
			replyToMessageID = &replyID
		}

		if storyIDFloat, exists := dataMap["story_id"].(float64); exists && storyIDFloat > 0 {
			storyIDUint := uint(storyIDFloat)
			storyID = &storyIDUint
		}

		if typeStr, exists := dataMap["type"].(string); exists {
			msgType = typeStr
		} else {
			msgType = "text"
		}

		if receiverID == 0 || content == "" {
			return
		}

		// 🚫 SPAM SHADOW-BAN — GLOBAL (yeni VƏ mövcud conversation üçün).
		//
		// Yalnız `actions` sütununa baxılır:
		//   • actions = NULL                  → mesaj BLOKLANIR
		//   • actions-da "message" var        → mesaj BLOKLANIR
		//   • actions = ["post","story"] və s.→ mesaj GEDƏ BİLƏR (mesaja təsir yox)
		// REST handler ilə eyni davranış.
		if models.IsMessagingBannedByActions(c.Hub.db, c.UserID) {
			log.Printf("🚫 SPAM SHADOW-BAN (WS): sender_id=%d → receiver_id=%d mesajı bloklandı (DB yazılmadı, WS yayılmadı)",
				c.UserID, receiverID)
			return
		}

		// 🎯 TEK SEFERDE: Conversation'ı getir + izin kontrolü yap
		//conversationHandler := handlers.NewConversationHandler(c.Hub, c.Hub.encryptionService)
		//conversation, canSend, errorMsg, err := conversationHandler.GetOrCreateConversationWithPermission(c.UserID, receiverID)

		conversation, canSend, errorMsg, err := c.Hub.getOrCreateConversationWithPermission(c.UserID, receiverID)

		if err != nil || !canSend {
			// 🚫 SPAM: spam'lı kullanıcıya hata bile gösterme — sessizce yut.
			// Mesaj DB'ye yazılmaz, karşı tarafa gitmez, gönderene message_error
			// dönülmez (shadow-ban davranışı).
			if errorMsg == spamSilentReason {
				log.Printf("Spam'lı kullanıcının mesajı sessizce engellendi: %d -> %d", c.UserID, receiverID)
				return
			}

			log.Printf("Mesaj gönderilemedi: %d -> %d, error: %v, msg: %s", c.UserID, receiverID, err, errorMsg)
			c.sendMessage(&OutgoingMessage{
				Type: "message_error",
				Data: map[string]interface{}{
					"error": errorMsg,
					"code":  "SEND_NOT_ALLOWED",
				},
			})
			return
		}

		messageID := uuid.New().String()
		createdAt := time.Now()

		// Conversation status belirle (nil ise "new", değilse mevcut status)
		conversationStatus := "new"
		if conversation != nil {
			conversationStatus = conversation.Status
		}

		// HandleNewMessage'a status geç. WS yolu səssiz göndərməni dəstəkləmir
		// (yalnız REST), ona görə silent=false.
		c.Hub.HandleNewMessage(c.UserID, receiverID, messageID, content, msgType, createdAt, replyToMessageID, storyID, conversationStatus, false)

		// DB yazma
		go func() {
			encryptedText, err := c.Hub.encryptionService.EncryptMessage(content)
			if err != nil {
				log.Printf("Mesaj şifreleme hatası: %v", err)
				return
			}

			message := models.Message{
				ID:               messageID,
				SenderID:         c.UserID,
				ReceiverID:       &receiverID,
				StoryID:          storyID,
				ReplyToMessageID: replyToMessageID,
				EncryptedText:    encryptedText,
				Read:             false,
				CreatedAt:        createdAt,
				UpdatedAt:        createdAt,
			}

			if err := c.Hub.db.Create(&message).Error; err != nil {
				log.Printf("Mesaj DB'ye yazılamadı: %v", err)
				return
			}

			// 🔍 MODERASIYA — mesaj DB-yə yazıldı, arxa-plan analizinə qoy.
			// Yalnız text mesajları analiz edirik. Qeyri-bloklayıcıdır.
			if c.Hub.moderationEnqueue != nil && (msgType == "" || msgType == "text") {
				c.Hub.moderationEnqueue(messageID, c.UserID, receiverID, content, createdAt)
			}
		}()

	case "mark_read":
		// Mesajları okundu olarak işaretle
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			log.Printf("mark_read data parse edilemedi")
			return
		}

		otherUserIDFloat, ok := dataMap["other_user_id"].(float64)
		if !ok {
			log.Printf("other_user_id eksik veya geçersiz")
			return
		}

		otherUserID := uint(otherUserIDFloat)
		c.Hub.handleMarkRead(c.UserID, otherUserID)

	case "mark_delivered":
		// Mesajları ÇATDIRILDI (delivered) olaraq işaretle — iki tick.
		// data.sender_id = mesajları GÖNDƏRƏN qarşı tərəf. Köhnə client-lər
		// bu frame-i göndərmir (tam additiv).
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			log.Printf("mark_delivered data parse edilemedi")
			return
		}

		senderIDFloat, ok := dataMap["sender_id"].(float64)
		if !ok {
			log.Printf("sender_id eksik veya geçersiz")
			return
		}

		c.Hub.handleMarkDelivered(c.UserID, uint(senderIDFloat))

	case "get_unread_count":
		// ✅ YENİ: Client'ın talep ettiği durumda okunmamış sayıyı gönder
		count := c.Hub.GetUnreadCount(c.UserID)
		response := &OutgoingMessage{
			Type: "unread_count",
			Data: map[string]interface{}{
				"count": count,
			},
		}
		c.sendMessage(response)

	case "chat_opened":
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			return
		}

		otherUserIDFloat, ok := dataMap["other_user_id"].(float64)
		if !ok {
			return
		}

		otherUserID := uint(otherUserIDFloat)
		c.Hub.SetActiveChat(c.UserID, &otherUserID)

	case "chat_closed":
		c.Hub.SetActiveChat(c.UserID, nil)

	// QRUP — DM chat_opened/chat_closed-un qrup ekvivalenti. Flutter
	// GroupChatPage açılanda group_chat_opened, bağlananda group_chat_closed
	// göndərir (websocket_chat_service.dart). Aktiv qrupdaykən həmin qrupun
	// push-u GETMİR.
	case "group_chat_opened":
		dataMap, ok := msg.Data.(map[string]interface{})
		if !ok {
			return
		}
		convIDFloat, ok := dataMap["conversation_id"].(float64)
		if !ok {
			return
		}
		convID := uint(convIDFloat)
		c.Hub.SetActiveGroupChat(c.UserID, &convID)

	case "group_chat_closed":
		c.Hub.SetActiveGroupChat(c.UserID, nil)

	case "screenshot_protection_changed":
		// Screenshot protection değişikliği için hiçbir şey yapmaya gerek yok
		// Bu sadece client'tan gelebilecek bir bildirim olabilir ama
		// normalde bu backend'den gelir, client'a gider
		log.Printf("Screenshot protection değişikliği alındı (bu normalde olmamalı)")

	default:
		log.Printf("Bilinmeyen mesaj tipi: %s", msg.Type)
	}
}

func (h *Hub) SetActiveChat(userID uint, chatWithUserID *uint) {
	h.mutex.Lock()
	defer h.mutex.Unlock()

	if client, exists := h.clients[userID]; exists {
		client.ActiveChatWith = chatWithUserID

		if chatWithUserID != nil {
			log.Printf("Kullanıcı %d aktif chat: %d", userID, *chatWithUserID)
		} else {
			log.Printf("Kullanıcı %d chat'ten çıktı", userID)
		}
	}
}

// IsUserInChatWith kontrol fonksiyonu
func (h *Hub) IsUserInChatWith(userID, otherUserID uint) bool {
	h.mutex.RLock()
	defer h.mutex.RUnlock()

	if client, exists := h.clients[userID]; exists {
		return client.ActiveChatWith != nil && *client.ActiveChatWith == otherUserID
	}
	return false
}

// SetActiveGroupChat — istifadəçinin hazırda açıq olan qrup çatını qeyd edir
// (nil = qrup səhifəsindən çıxdı). SetActiveChat-in qrup ekvivalenti.
func (h *Hub) SetActiveGroupChat(userID uint, conversationID *uint) {
	h.mutex.Lock()
	defer h.mutex.Unlock()

	if client, exists := h.clients[userID]; exists {
		client.ActiveGroupChat = conversationID

		if conversationID != nil {
			log.Printf("Kullanıcı %d aktif grup chat: %d", userID, *conversationID)
		} else {
			log.Printf("Kullanıcı %d grup chat'ten çıktı", userID)
		}
	}
}

// IsUserInGroupChat — istifadəçi hazırda BU qrupun səhifəsindədirmi?
// True isə qrup mesajı push-u GÖNDƏRİLMİR (DM IsUserInChatWith məntiqi).
func (h *Hub) IsUserInGroupChat(userID, conversationID uint) bool {
	h.mutex.RLock()
	defer h.mutex.RUnlock()

	if client, exists := h.clients[userID]; exists {
		return client.ActiveGroupChat != nil && *client.ActiveGroupChat == conversationID
	}
	return false
}

// sendMessage client'a mesaj gönder
func (c *Client) sendMessage(msg *OutgoingMessage) {
	data, err := json.Marshal(msg)
	if err != nil {
		log.Printf("JSON marshal hatası: %v", err)
		return
	}

	select {
	case c.Send <- data:
	default:
		log.Printf("Client %d için mesaj gönderilemedi", c.UserID)
	}
}

// writePump client'a mesaj yaz
func (c *Client) writePump() {
	ticker := time.NewTicker(54 * time.Second)
	defer func() {
		ticker.Stop()
		err := c.Conn.Close()
		if err != nil {
			return
		}
	}()

	for {
		select {
		case message, ok := <-c.Send:
			err := c.Conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err != nil {
				return
			}
			if !ok {
				err := c.Conn.WriteMessage(websocket.CloseMessage, []byte{})
				if err != nil {
					return
				}
				return
			}

			if err := c.Conn.WriteMessage(websocket.TextMessage, message); err != nil {
				log.Printf("Mesaj yazma hatası: %v", err)
				return
			}

		case <-ticker.C:
			err := c.Conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if err != nil {
				return
			}
			if err := c.Conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				return
			}
		}
	}
}

// ScheduleGroupPushNotification — GECİKMƏLİ qrup push-u (anti-spam):
// dərhal göndərmək əvəzinə `delay` gözləyir, göndərmədən ƏVVƏL hər alıcı
// üçün yoxlayır:
//  1. Mesajı artıq OXUYUB? (message_reads)        → push GETMİR
//  2. Qrup səhifəsi hazırda AÇIQDIR? (ActiveGroupChat) → push GETMİR
//
// Qalan alıcılara normal push gedir. Telegram/Slack yanaşması — istifadəçi
// mesajı onsuz da görübsə telefon heç titrəmir.
func (h *Hub) ScheduleGroupPushNotification(
	conversationID, senderID uint,
	groupName, message, messageID string,
	memberIDs []uint,
	delay time.Duration,
) {
	time.AfterFunc(delay, func() {
		remaining := make([]uint, 0, len(memberIDs))
		for _, uid := range memberIDs {
			if uid == senderID {
				continue
			}
			// Hazırda qrup səhifəsindədir — mesajı canlı görür.
			if h.IsUserInGroupChat(uid, conversationID) {
				continue
			}
			// Gecikmə pəncərəsində OXUDU — push artıq lazımsız.
			var readCount int64
			h.db.Table("message_reads").
				Where("message_id = ? AND user_id = ?", messageID, uid).
				Count(&readCount)
			if readCount > 0 {
				continue
			}
			remaining = append(remaining, uid)
		}

		if len(remaining) == 0 {
			return // hamı oxudu/baxır — push YOX
		}
		h.SendGroupPushNotification(conversationID, senderID, groupName, message, remaining)
	})
}

// SendDismissThreadPush — istifadəçi söhbəti OXUYANDA cihazındakı həmin
// thread bildirişlərini tepsidən silmək üçün Laravel-ə silent dismiss push
// tapşırığı göndərir (`/notification/dismiss-thread`). Qeyri-bloklayıcı.
func (h *Hub) SendDismissThreadPush(userID uint, threadID string) {
	go func() {
		if h.config.CloudToken == "" || h.config.BackendUrl == "" {
			return
		}
		payload := map[string]interface{}{
			"user_id":   userID,
			"thread_id": threadID,
		}
		jsonData, err := json.Marshal(payload)
		if err != nil {
			return
		}
		req, err := http.NewRequest("POST",
			h.config.BackendUrl+"/notification/dismiss-thread",
			bytes.NewBuffer(jsonData))
		if err != nil {
			return
		}
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("x-api-key", h.config.CloudToken)
		resp, err := h.httpClient.Do(req)
		if err != nil {
			return
		}
		resp.Body.Close()
	}()
}

// SendGroupPushNotification qrup mesajı üçün push notification göndərir (async).
// memberIDs — mute olmayan üzvlər (göndərən onsuz da Go tərəfdə çıxarılıb, amma
// Laravel də sender_id-ni təhlükəsizlik üçün siyahıdan çıxarır). Laravel
// `/notification/new-group-message` endpoint-i hamısına FCM göndərir.
func (h *Hub) SendGroupPushNotification(conversationID, senderID uint, groupName, message string, memberIDs []uint) {
	go func() {
		if len(memberIDs) == 0 {
			return
		}
		if h.config.CloudToken == "" {
			log.Printf("❌ CloudToken boş! (qrup push)")
			return
		}
		if h.config.BackendUrl == "" {
			log.Printf("❌ BackendUrl boş! (qrup push)")
			return
		}

		url := h.config.BackendUrl + "/notification/new-group-message"
		payload := map[string]interface{}{
			"receiver_ids":    memberIDs,
			"sender_id":       senderID,
			"conversation_id": conversationID,
			"group_name":      groupName,
			"message":         message,
		}

		jsonData, err := json.Marshal(payload)
		if err != nil {
			log.Printf("❌ Qrup push payload marshal hatası: %v", err)
			return
		}

		req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
		if err != nil {
			log.Printf("❌ Qrup push request oluşturma hatası: %v", err)
			return
		}
		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("x-api-key", h.config.CloudToken)

		resp, err := h.httpClient.Do(req)
		if err != nil {
			log.Printf("❌ Qrup push göndərmə hatası: %v", err)
			return
		}
		defer resp.Body.Close()

		if resp.StatusCode == 200 {
			log.Printf("✅ Qrup push göndərildi: conv=%d sender=%d → %d üzv", conversationID, senderID, len(memberIDs))
		} else {
			log.Printf("❌ Qrup push uğursuz, status: %d", resp.StatusCode)
		}
	}()
}

// sendPushNotification push notification göndər (async)
func (h *Hub) sendPushNotification(senderID, receiverID uint, message, msgType string) {
	go func() {
		// Önce conversation'ı bulup mute kontrolü yap
		var conversation models.Conversation
		err := h.db.Where("(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)",
			senderID, receiverID, receiverID, senderID).First(&conversation).Error

		if err != nil {
			log.Printf("❌ Conversation bulunamadı, notification gönderilmiyor: %v", err)
			return
		}

		// Receiver söhbəti arxivləyibsə push GÖNDƏRMƏ (arxiv = səssiz,
		// Telegram davranışı). Per-user: yalnız receiver-in öz arxiv bayrağı.
		var isArchivedByReceiver bool
		if conversation.User1ID == receiverID {
			isArchivedByReceiver = conversation.User1Archived
		} else {
			isArchivedByReceiver = conversation.User2Archived
		}
		if isArchivedByReceiver {
			log.Printf("🗄️ Kullanıcı %d konuşmayı arşivlemiş, notification gönderilmiyor", receiverID)
			return
		}

		// Receiver'ın mute durumunu kontrol et
		var isMuted bool
		var mutedUntil *time.Time

		if conversation.User1ID == receiverID {
			isMuted = conversation.User1Muted
			mutedUntil = conversation.User1MutedUntil
		} else {
			isMuted = conversation.User2Muted
			mutedUntil = conversation.User2MutedUntil
		}

		// Mute kontrolü
		if isMuted {
			// Eğer sürekli mute ise (MutedUntil == nil) notification gönderme
			if mutedUntil == nil {
				log.Printf("🔕 Kullanıcı %d sürekli mute, notification gönderilmiyor", receiverID)
				return
			}

			// Eğer mute süresi henüz bitmemişse notification gönderme
			if time.Now().Before(*mutedUntil) {
				log.Printf("🔕 Kullanıcı %d mute (bitiş: %s), notification gönderilmiyor",
					receiverID, mutedUntil.Format("15:04:05"))
				return
			}

			// Mute süresi bitmiş, mute'u kaldır
			if conversation.User1ID == receiverID {
				conversation.User1Muted = false
				conversation.User1MutedUntil = nil
			} else {
				conversation.User2Muted = false
				conversation.User2MutedUntil = nil
			}

			h.db.Save(&conversation)
			log.Printf("🔔 Kullanıcı %d mute süresi bittiği için mute kaldırıldı", receiverID)
		}

		// Mute değilse normal notification gönderme işlemi
		url := h.config.BackendUrl + "/notification/new-message"

		var notificationMessage string
		switch msgType {
		case "image":
			notificationMessage = "Image"
		case "video":
			notificationMessage = "Video"
		case "voice":
			notificationMessage = "Voice"
		default:
			notificationMessage = message
		}

		if h.config.CloudToken == "" {
			log.Printf("❌ CloudToken boş!")
			return
		}
		if h.config.BackendUrl == "" {
			log.Printf("❌ BackendUrl boş!")
			return
		}

		payload := map[string]interface{}{
			"receiver_id": receiverID,
			"sender_id":   senderID,
			"message":     notificationMessage,
		}

		jsonData, err := json.Marshal(payload)
		if err != nil {
			log.Printf("❌ Notification payload marshal hatası: %v", err)
			return
		}

		req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
		if err != nil {
			log.Printf("❌ Notification request oluşturma hatası: %v", err)
			return
		}

		req.Header.Set("Content-Type", "application/json")
		req.Header.Set("x-api-key", h.config.CloudToken)

		resp, err := h.httpClient.Do(req)
		if err != nil {
			log.Printf("❌ Push notification gönderme hatası: %v", err)
			return
		}
		defer resp.Body.Close()

		if resp.StatusCode == 200 {
			log.Printf("✅ Push notification gönderildi: %d -> %d", senderID, receiverID)
		} else {
			log.Printf("❌ Push notification başarısız, status: %d", resp.StatusCode)
		}
	}()
}

// GetUnreadCount kullanıcının okunmamış mesaj sayısını getir
func (h *Hub) GetUnreadCount(userID uint) int {
	var count int64

	query := `
		SELECT COUNT(*) 
		FROM messages 
		WHERE receiver_id = ? 
		AND read = false 
		AND is_deleted_by_receiver = false
	`

	if err := h.db.Raw(query, userID).Scan(&count).Error; err != nil {
		log.Printf("Okunmamış mesaj sayısı alınamadı: %v", err)
		return 0
	}

	return int(count)
}

// SendUnreadCountUpdate kullanıcıya okunmamış mesaj sayısını gönder
func (h *Hub) SendUnreadCountUpdate(userID uint) {
	count := h.GetUnreadCount(userID)

	h.SendToUser(userID, "unread_count_update", map[string]interface{}{
		"count": count,
	})

	log.Printf("Okunmamış mesaj sayısı gönderildi: User %d, Count: %d", userID, count)
}

// handleGroupTyping qrupda yazma/dayandırma siqnalını həmin qrupun digər
// aktiv üzvlərinə yayır. data içindən conversation_id çıxarılır (JSON number
// → float64). DM "typing" ilə simmetrikdir, amma tək receiver yerine qrup
// üzvlərinə (göndərən istisna) göndərilir.
func (h *Hub) handleGroupTyping(userID uint, data interface{}, isTyping bool) {
	dataMap, ok := data.(map[string]interface{})
	if !ok {
		return
	}
	convFloat, ok := dataMap["conversation_id"].(float64)
	if !ok || convFloat <= 0 {
		return
	}
	conversationID := uint(convFloat)

	// Action: "typing" (default) və ya "recording" (səs yazır). Flutter
	// data-da göndərə bilər; göndərməsə typing sayılır.
	action := "typing"
	if a, ok := dataMap["action"].(string); ok && a == "recording" {
		action = "recording"
	}

	// Yazanın adı/avatarı — çatda inline göstərmək üçün (avatar + "X yazır").
	var sender struct {
		Name         string  `gorm:"column:name"`
		Username     string  `gorm:"column:username"`
		ProfileImage *string `gorm:"column:profile_image"`
	}
	h.db.Raw(`
		SELECT u.name, u.username, p.profile_image
		FROM users u
		LEFT JOIN profiles p ON p.user_id = u.id
		WHERE u.id = ?
	`, userID).Scan(&sender)

	// Qrupun aktiv üzvlərini çək (left_at IS NULL).
	var memberIDs []uint
	h.db.Model(&models.ConversationParticipant{}).
		Where("conversation_id = ? AND left_at IS NULL AND deleted_at IS NULL", conversationID).
		Pluck("user_id", &memberIDs)

	for _, mid := range memberIDs {
		if mid == userID {
			continue // göndərənə qaytarma
		}
		h.SendToUser(mid, "group_typing", map[string]interface{}{
			"conversation_id": conversationID,
			"user_id":         userID,
			"typing":          isTyping,
			"action":          action,
			"sender_name":     sender.Name,
			"sender_username": sender.Username,
			"sender_avatar":   utils.PrependBaseURL(sender.ProfileImage),
		})
	}
}

// handleAddReaction mesaja reaction ekle
func (h *Hub) handleAddReaction(userID uint, messageID, emoji string) {
	var message models.Message
	if err := h.db.Where("id = ?", messageID).First(&message).Error; err != nil {
		log.Printf("Mesaj bulunamadı: %v", err)
		return
	}

	// Kullanıcının bu mesaja reaction verebilir mi kontrol et
	if userID != message.SenderID && (message.ReceiverID == nil || userID != *message.ReceiverID) {
		log.Printf("Kullanıcı %d bu mesaja reaction veremez", userID)
		return
	}

	// ✅ İdempotensiya: eyni istifadəçi eyni emoji-ni təkrar atırsa, push göndərmə
	isDuplicate := false
	if userID == message.SenderID {
		if message.SenderReaction != nil && *message.SenderReaction == emoji {
			isDuplicate = true
		}
	} else {
		if message.ReceiverReaction != nil && *message.ReceiverReaction == emoji {
			isDuplicate = true
		}
	}

	// Reaction güncelle
	if userID == message.SenderID {
		message.SenderReaction = &emoji
	} else {
		message.ReceiverReaction = &emoji
	}

	now := time.Now().UTC()
	message.UpdatedAt = now

	if err := h.db.Save(&message).Error; err != nil {
		log.Printf("Reaction kaydedilemedi: %v", err)
		return
	}

	// WebSocket ile bildir
	reactionData := map[string]interface{}{
		"message_id": messageID,
		"user_id":    userID,
		"emoji":      emoji,
		"action":     "added",
	}

	h.SendToUser(message.SenderID, "reaction_updated", reactionData)
	if message.ReceiverID != nil {
		h.SendToUser(*message.ReceiverID, "reaction_updated", reactionData)
	}

	// ✅ YENİ: Conversation last_reaction sütunlarını yenilə və conversations siyahısına yay
	if message.ReceiverID != nil {
		h.updateConversationLastReaction(message.SenderID, *message.ReceiverID, userID, emoji, now, "added")

		// Reaksiyanı qarşı tərəfə push notification kimi göndər (mute olmayanlara,
		// yalnız reaksiya əslində dəyişibsə — duplikat-da push atma)
		if !isDuplicate {
			otherUserID := message.SenderID
			if userID == message.SenderID {
				otherUserID = *message.ReceiverID
			}
			if otherUserID != userID {
				if !h.IsUserOnline(otherUserID) || !h.IsUserInChatWith(otherUserID, userID) {
					go h.sendReactionPushNotification(userID, otherUserID, emoji)
				}
			}
		}
	}

	log.Printf("Reaction eklendi: User %d, Message %s, Emoji %s", userID, messageID, emoji)
}

// handleRemoveReaction mesajdan reaction kaldır
func (h *Hub) handleRemoveReaction(userID uint, messageID string) {
	var message models.Message
	if err := h.db.Where("id = ?", messageID).First(&message).Error; err != nil {
		log.Printf("Mesaj bulunamadı: %v", err)
		return
	}

	if userID != message.SenderID && (message.ReceiverID == nil || userID != *message.ReceiverID) {
		return
	}

	// Reaction kaldır
	if userID == message.SenderID {
		message.SenderReaction = nil
	} else {
		message.ReceiverReaction = nil
	}

	now := time.Now().UTC()
	message.UpdatedAt = now

	if err := h.db.Save(&message).Error; err != nil {
		log.Printf("Reaction kaldırılamadı: %v", err)
		return
	}

	// WebSocket ile bildir
	reactionData := map[string]interface{}{
		"message_id": messageID,
		"user_id":    userID,
		"action":     "removed",
	}

	h.SendToUser(message.SenderID, "reaction_updated", reactionData)
	if message.ReceiverID != nil {
		h.SendToUser(*message.ReceiverID, "reaction_updated", reactionData)
	}

	// ✅ YENİ: Reaksiya silindikdə conversations siyahısında son mesaja geri dön
	if message.ReceiverID != nil {
		h.updateConversationLastReaction(message.SenderID, *message.ReceiverID, userID, "", now, "removed")
	}

	log.Printf("Reaction kaldırıldı: User %d, Message %s", userID, messageID)
}

// updateConversationLastReaction conversations cədvəlində son reaksiya sütunlarını yenil
// və hər iki istifadəçinin conversations siyahısına `conversation_update` event göndər.
//
// action: "added" və ya "removed"
func (h *Hub) updateConversationLastReaction(senderID, receiverID, reactorID uint, emoji string, at time.Time, action string) {
	// Conversation-ı tap
	var conversation models.Conversation
	err := h.db.Where(
		"(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)",
		senderID, receiverID, receiverID, senderID,
	).First(&conversation).Error
	if err != nil {
		log.Printf("⚠️ Reaction üçün conversation tapılmadı: %v", err)
		return
	}

	updates := map[string]interface{}{}
	if action == "added" {
		updates["last_reaction_emoji"] = emoji
		updates["last_reaction_at"] = at
		updates["last_reaction_by_user_id"] = reactorID
	} else {
		// removed → reaksiya sütunlarını sıfırla
		updates["last_reaction_emoji"] = nil
		updates["last_reaction_at"] = nil
		updates["last_reaction_by_user_id"] = nil
	}

	if err := h.db.Model(&conversation).Updates(updates).Error; err != nil {
		log.Printf("⚠️ conversation last_reaction yenilənə bilmədi: %v", err)
		// Yenilənmə uğursuz olsa da broadcast etməyə davam edək
	}

	// İki tərəf üçün də conversation_update yay
	atStr := ""
	if action == "added" {
		atStr = at.Format(time.RFC3339)
	}

	buildPayload := func(otherUserID uint, isFromMe bool) map[string]interface{} {
		payload := map[string]interface{}{
			"type":                     "conversation_update",
			"event":                    "reaction_" + action, // reaction_added / reaction_removed
			"other_user_id":            otherUserID,
			"last_reaction_emoji":      nilIfEmpty(emoji, action),
			"last_reaction_at":         nilIfEmptyStr(atStr),
			"last_reaction_by_user_id": reactorID,
			"is_reaction_from_me":      isFromMe,
		}
		return payload
	}

	// senderID üçün: qarşı tərəf receiverID
	h.SendToUser(senderID, "conversation_update", buildPayload(receiverID, reactorID == senderID))
	// receiverID üçün: qarşı tərəf senderID
	h.SendToUser(receiverID, "conversation_update", buildPayload(senderID, reactorID == receiverID))
}

// nilIfEmpty action=removed olduqda emoji boşdur, JSON-da null göndərək
func nilIfEmpty(emoji, action string) interface{} {
	if action == "removed" || emoji == "" {
		return nil
	}
	return emoji
}

func nilIfEmptyStr(s string) interface{} {
	if s == "" {
		return nil
	}
	return s
}

// sendReactionPushNotification reaksiya üçün push notification göndər (async)
func (h *Hub) sendReactionPushNotification(reactorID, receiverID uint, emoji string) {
	// Mute statusunu yoxla — eyni məntiq sendPushNotification-da olduğu kimi
	var conversation models.Conversation
	err := h.db.Where("(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)",
		reactorID, receiverID, receiverID, reactorID).First(&conversation).Error
	if err != nil {
		log.Printf("❌ Reaction push: conversation tapılmadı: %v", err)
		return
	}

	var isMuted bool
	var mutedUntil *time.Time
	if conversation.User1ID == receiverID {
		isMuted = conversation.User1Muted
		mutedUntil = conversation.User1MutedUntil
	} else {
		isMuted = conversation.User2Muted
		mutedUntil = conversation.User2MutedUntil
	}

	if isMuted {
		if mutedUntil == nil {
			log.Printf("🔕 Reaction push: User %d sürəkli mute", receiverID)
			return
		}
		if time.Now().Before(*mutedUntil) {
			log.Printf("🔕 Reaction push: User %d mute (bitiş: %s)", receiverID, mutedUntil.Format("15:04:05"))
			return
		}
	}

	if h.config.CloudToken == "" || h.config.BackendUrl == "" {
		log.Printf("❌ Reaction push: CloudToken və ya BackendUrl boşdur")
		return
	}

	// Notification mətni Azərbaycanca
	// Backend FCM servisi adətən "Ali: <message>" formasında title/body düzəldir.
	notificationMessage := "Mesajınıza " + emoji + " ilə reaksiya verdi"

	url := h.config.BackendUrl + "/notification/new-message"
	payload := map[string]interface{}{
		"receiver_id": receiverID,
		"sender_id":   reactorID,
		"message":     notificationMessage,
		"type":        "reaction",
		"emoji":       emoji,
	}

	jsonData, err := json.Marshal(payload)
	if err != nil {
		log.Printf("❌ Reaction notification payload marshal xətası: %v", err)
		return
	}

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonData))
	if err != nil {
		log.Printf("❌ Reaction notification request xətası: %v", err)
		return
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", h.config.CloudToken)

	resp, err := h.httpClient.Do(req)
	if err != nil {
		log.Printf("❌ Reaction push göndərmə xətası: %v", err)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode == 200 {
		log.Printf("✅ Reaction push göndərildi: %d -> %d (%s)", reactorID, receiverID, emoji)
	} else {
		log.Printf("❌ Reaction push uğursuz, status: %d", resp.StatusCode)
	}
}

// handleMarkRead kullanıcının mesajlarını okundu olarak işaretle
func (h *Hub) handleMarkRead(readerID, otherUserID uint) {
	// Bu conversation'daki okunmamış mesajları okundu olarak işaretle.
	// Oxundu = çatdırıldı da (read implies delivered) — ayrıca message_delivered
	// event-i lazım deyil, mövcud message_read göndərəni onsuz da xəbərdar edir.
	result := h.db.Model(&models.Message{}).
		Where("sender_id = ? AND receiver_id = ? AND read = false", otherUserID, readerID).
		Updates(map[string]interface{}{"read": true, "delivered": true})

	if result.Error != nil {
		log.Printf("Mesajları okundu olarak işaretleme hatası: %v", result.Error)
		return
	}

	// Kaç mesaj okundu olarak işaretlendi
	updatedCount := result.RowsAffected

	if updatedCount > 0 {
		// Mesaj gönderende unread count güncelle
		go h.SendUnreadCountUpdate(otherUserID)

		// Mesaj gönderen kişiye bildir (message_read event)
		readData := map[string]interface{}{
			"reader_id":     readerID,
			"other_user_id": otherUserID,
			"read_count":    updatedCount,
		}

		h.SendToUser(otherUserID, "message_read", readData)

		log.Printf("Mesajlar okundu olarak işaretlendi: %d mesaj, reader: %d, sender: %d",
			updatedCount, readerID, otherUserID)
	}
}

// handleMarkDelivered — qarşı tərəfin (senderID) recipientID-yə göndərdiyi, hələ
// çatdırılmamış mesajları delivered=true işarələyir və göndərənə
// `message_delivered` event-i ilə bildirir (iki tick). Oxundu (read) ayrıca
// axındır — bax handleMarkRead. Client `mark_delivered` frame-ini push/offline
// gəlişlərində göndərir; canlı WS çatdırılması üçün bax maybeMarkLivePushDelivered.
func (h *Hub) handleMarkDelivered(recipientID, senderID uint) {
	// Əvvəlcə təsirlənəcək mesaj id-ləri (ən yenidən köhnəyə, maks 500) —
	// event-də göndərmək üçün. 500-dən çox varsa HAMISI update olunur, amma
	// event yalnız son 500 id + "all_before" daşıyır (client bulk tətbiq edir).
	type deliveredRow struct {
		ID        string    `gorm:"column:id"`
		CreatedAt time.Time `gorm:"column:created_at"`
	}
	var rows []deliveredRow
	if err := h.db.Model(&models.Message{}).
		Select("id, created_at").
		Where("sender_id = ? AND receiver_id = ? AND delivered = false", senderID, recipientID).
		Order("created_at DESC").
		Limit(500).
		Scan(&rows).Error; err != nil {
		log.Printf("mark_delivered id seçimi xətası: %v", err)
		return
	}

	if len(rows) == 0 {
		return
	}

	result := h.db.Model(&models.Message{}).
		Where("sender_id = ? AND receiver_id = ? AND delivered = false", senderID, recipientID).
		Update("delivered", true)

	if result.Error != nil {
		log.Printf("Mesajları delivered olarak işaretleme hatası: %v", result.Error)
		return
	}

	if result.RowsAffected == 0 {
		return
	}

	messageIDs := make([]string, 0, len(rows))
	for _, r := range rows {
		messageIDs = append(messageIDs, r.ID)
	}

	deliveredData := map[string]interface{}{
		"other_user_id": recipientID,
		"message_ids":   messageIDs,
	}

	// 500-dən çox təsirləndi → id siyahısı kəsilib. Ən yeni təsirlənən mesajın
	// vaxtı verilir ki, client ondan ƏVVƏLKİ bütün mesajları delivered saysın.
	if result.RowsAffected > int64(len(rows)) {
		deliveredData["all_before"] = rows[0].CreatedAt.UTC().Format(time.RFC3339)
	}

	// Göndərən onlayn deyilsə SendToUser sadəcə heç nə etmir (clients map-də yoxdur).
	h.SendToUser(senderID, "message_delivered", deliveredData)
}

// BroadcastScreenshotProtectionChange screenshot koruma değişikliğini her iki kullanıcıya bildir
func (h *Hub) BroadcastScreenshotProtectionChange(user1ID, user2ID uint, isDisabled bool, changedByUserID uint) {
	screenshotData := map[string]interface{}{
		"is_screenshot_disabled": isDisabled,
		"changed_by":             changedByUserID,
		"changed_at":             time.Now().UTC(),
	}

	// Her iki kullanıcıya da bildir
	h.SendToUser(user1ID, "screenshot_protection_changed", screenshotData)
	h.SendToUser(user2ID, "screenshot_protection_changed", screenshotData)

	log.Printf("Screenshot protection değişikliği yayınlandı: User1: %d, User2: %d, Disabled: %t, ChangedBy: %d",
		user1ID, user2ID, isDisabled, changedByUserID)
}

// spamSilentReason — spam'lı kullanıcının mesaj denemesinde dönülen sentinel
// errorMsg değeri. Çağıran kod bunu görünce kullanıcıya hata göstermeden
// sessizce çıkar (shadow-ban).
const spamSilentReason = "__SPAM_SILENT__"

func (h *Hub) getOrCreateConversationWithPermission(senderID, receiverID uint) (*models.Conversation, bool, string, error) {
	var conversation models.Conversation
	err := h.db.Where(
		"(user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)",
		senderID, receiverID, receiverID, senderID,
	).First(&conversation).Error

	if err != nil {
		// 🚫 SPAM KONTROLÜ: spam_bans'ta kaydı olan (deleted_at IS NULL)
		// kullanıcı YENİ conversation başlatamaz. Sessizce başarısız ol —
		// sentinel reason döndür, conversation oluşturma.
		if models.IsMessagingBanned(h.db, senderID) {
			return nil, false, spamSilentReason, nil
		}

		// 🚫 ACTIONS KONTROLÜ: spam_bans aktiv qeydinin `actions` sütunu
		// mesaj göndərməni qadağan edirsə (NULL, ya da массivində "message"
		// varsa) — YENİ conversation başlada bilməz. Eyni səssiz shadow-ban.
		if models.IsMessagingBannedByActions(h.db, senderID) {
			return nil, false, spamSilentReason, nil
		}

		// Conversation yok, yeni oluştur
		newConv := models.Conversation{
			User1ID: senderID,
			User2ID: receiverID,
			Status:  "pending",
		}
		if err := h.db.Create(&newConv).Error; err != nil {
			return nil, false, "conversation oluşturulamadı", err
		}
		return &newConv, true, "", nil
	}

	if conversation.Status == "blocked" {
		return nil, false, "Bu kullanıcıya mesaj gönderemezsiniz", nil
	}

	// 🚫 ADMIN BLOK — söhbət admin (Filament) tərəfindən bloklanıbsa, BU
	// söhbətdə heç kim yeni mesaj göndərə bilməz (nə user1, nə user2).
	// spamSilentReason qaytarılır → WS handler mesajı SƏSSİZCƏ udar
	// (göndərənə xəta getmir, qarşı tərəfə çatmır). Köhnə mesajlar qalır.
	if conversation.Blocked {
		return nil, false, spamSilentReason, nil
	}

	return &conversation, true, "", nil
}
